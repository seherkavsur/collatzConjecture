#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


unsigned int display_collatz(unsigned long long val)
{
	
	int count=1;
	

	while (val != 1)
	{
		printf("%llu    ", val);

		if (val % 2 == 0)
		{
			val = val / 2;
			printf("%llu   ", val);
			
		}
		else if (val % 2 == 1)
		{
			val = 3 * val + 1;
			printf("%llu   ", val);
			
		}

		++count;

	}
	return count;
}

int main()
{
	unsigned long long number;
	int count;
	printf("enter a number\n");
	scanf("%llu",&number);

	count = display_collatz(number);
	printf("%d", count);
	system("PAUSE");
}
